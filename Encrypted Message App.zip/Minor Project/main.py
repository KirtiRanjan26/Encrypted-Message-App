from flask import Flask, render_template, request, flash, redirect, url_for
from cryptography.fernet import Fernet
import base64
import os

app = Flask(__name__)
app.secret_key = 'your_flask_secret_key_here'  # Change this for production

# Placeholder for the key (replace with a real one after generation)
KEY = b'your-base64-encoded-32-byte-key-here=='

# Generate a valid key if the placeholder is still in use (runs at module load)
if KEY == b'your-base64-encoded-32-byte-key-here==':
    print("Generating a new Fernet key (run once, then update KEY in code)...")
    KEY = Fernet.generate_key()
    print(f"Generated KEY (copy-paste this into the code): {KEY.decode()}")
    print("Example: KEY = b'" + KEY.decode() + "'")

# Now create the cipher suite with a valid key
cipher_suite = Fernet(KEY)

@app.route('/', methods=['GET'])
def index():
    return render_template('index.html')

@app.route('/encrypt', methods=['POST'])
def encrypt():
    plaintext = request.form.get('plaintext', '').strip()
    if not plaintext:
        flash('Please enter a message to encrypt.')
        return redirect(url_for('index'))
    
    try:
        # Encrypt the message
        encrypted_bytes = cipher_suite.encrypt(plaintext.encode('utf-8'))
        # Fernet output is already URL-safe base64, but we re-encode for safety/consistency
        encrypted_b64 = base64.urlsafe_b64encode(encrypted_bytes).decode('utf-8')
        
        # Render with result
        return render_template('index.html', encrypted=encrypted_b64)
    except Exception as e:
        flash(f'Encryption failed: {str(e)}')
        return redirect(url_for('index'))

@app.route('/decrypt', methods=['POST'])
def decrypt():
    ciphertext_b64 = request.form.get('ciphertext', '').strip()
    if not ciphertext_b64:
        flash('Please enter ciphertext to decrypt.')
        return redirect(url_for('index'))
    
    try:
        # URL-safe base64 decode the input
        encrypted_bytes = base64.urlsafe_b64decode(ciphertext_b64.encode('utf-8'))
        # Decrypt
        decrypted_bytes = cipher_suite.decrypt(encrypted_bytes)
        decrypted = decrypted_bytes.decode('utf-8')
        
        # Render with result
        return render_template('index.html', decrypted=decrypted)
    except Exception as e:
        flash(f'Decryption failed (invalid key or ciphertext?): {str(e)}')
        return redirect(url_for('index'))

if __name__ == '__main__':
    app.run(debug=True)